"""Visual intelligence — the researcher should not need to know chart names.

Input: an analysis result, the variables it used, and what the figure is for.
Output: a recommended visual, the reason, a ResearchVisualSpec, a caption, an
interpretation and the alternatives that were considered.

The recommendation is deterministic and rule-based. That is a deliberate choice:
chart selection follows from the analysis method and the variable types, both of
which the system already knows exactly. Asking a language model to guess would
add nondeterminism and a fabrication risk to a decision that has a correct
answer.
"""

from __future__ import annotations

from typing import Any, Mapping

from .labels import LabelBook
from .spec import (
    Annotation,
    Encoding,
    ResearchVisualSpec,
    Scale,
    UncertaintyDisplay,
    VisualType,
)


class RecommendationError(ValueError):
    pass


#: The book a caller gets when it supplies none: every label falls back to the
#: humanised column name, which is exactly the behaviour that existed before
#: labels were plumbed through. Shared because `LabelBook` has no mutators.
_NO_LABELS = LabelBook()


def recommend(
    *,
    analysis_run_id: str,
    method: str,
    variables: dict[str, Any],
    result: dict[str, Any],
    dataset_version_id: str | None = None,
    goal: str = "show the relationship",
    audience: str = "researcher",
    labels: LabelBook | Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Choose a figure for an analysis result.

    `labels` maps each raw column name to what a reader should see instead —
    normally built from the canonical variable layer by the caller that holds a
    database cursor. Omitting it is supported and produces the humanised raw
    name, which is the only label available when nothing else is known.
    """
    book = LabelBook.coerce(labels)
    builders = {
        "pearson_correlation": _correlation,
        "spearman_correlation": _correlation,
        "bootstrap_correlation": _correlation,
        "linear_regression": _regression,
        "t_test": _group_comparison,
        "mann_whitney": _group_comparison,
        "anova": _group_comparison,
        "kruskal_wallis": _group_comparison,
        "chi_square": _contingency,
        "descriptive": _descriptive,
    }
    builder = builders.get(method)
    if builder is None:
        raise RecommendationError(
            f"No visualization is defined for {method!r}. "
            f"Supported: {', '.join(sorted(builders))}"
        )
    recommendation = builder(analysis_run_id, dataset_version_id, variables, result,
                             audience, book)
    recommendation["goal"] = goal
    recommendation["audience"] = audience
    return recommendation


def _significance_note(result: dict[str, Any]) -> str:
    """A caption fragment that keeps 's separations intact."""
    parts: list[str] = []
    if result.get("p_value") is not None:
        parts.append(f"p = {result['p_value']:.3g}")
    effect = result.get("effect_size") or {}
    if effect.get("value") is not None:
        parts.append(f"{effect.get('name', 'effect')} = {effect['value']:.3g}")
    if result.get("sample_size"):
        parts.append(f"n = {result['sample_size']}")
    if result.get("evidence_quality"):
        parts.append(f"evidence: {result['evidence_quality']}")
    return "; ".join(parts)


#: Sample size beyond which one mark per observation stops being readable.
#:
#: Overplotting has no threshold of its own — a scatter degrades continuously and
#: never announces it. This is the point where, at publication figure sizes, the
#: dense region of a typical correlation goes solid and the reader can no longer
#: tell fifty points from five thousand. Below it a scatter is strictly better,
#: because it shows every observation; above it the scatter is showing ink.
OVERPLOTTING_THRESHOLD = 5_000


def _correlation(run_id, version_id, variables, result, audience,
                 book=_NO_LABELS) -> dict[str, Any]:
    x_name, y_name = variables["x"], variables["y"]
    has_ci = result.get("ci_low") is not None
    sample_size = int(result.get("sample_size") or 0)

    if sample_size >= OVERPLOTTING_THRESHOLD:
        return _binned_correlation(run_id, version_id, x_name, y_name,
                                   result, sample_size, book)

    spec = ResearchVisualSpec(
        visual_type=VisualType.SCATTER,
        analysis_run_id=run_id, dataset_version_id=version_id,
        x=book.encoding(x_name),
        y=book.encoding(y_name),
        uncertainty=UncertaintyDisplay.BAND if has_ci else UncertaintyDisplay.NONE,
        annotations=[Annotation(kind="regression_line",
                                text="least-squares fit, shown for orientation only")],
        title=f"{book.label(y_name)} against {book.label(x_name)}",
        #  — the caption must not imply causation from a correlation.
        caption=(f"Association between {book.described(x_name)} and "
                 f"{book.described(y_name)}. {_significance_note(result)}. "
                 "Association does not establish causation."),
        interaction=["hover", "brush", "underlying_table"],
    )
    return {
        "visual_type": VisualType.SCATTER,
        "reason": ("A scatter plot shows every observation, so the reader can judge the "
                   "shape of the relationship and see outliers rather than trusting a "
                   "single coefficient."),
        "spec": spec,
        "interpretation": result.get("interpretation", ""),
        "alternatives": [
            {"visual_type": VisualType.HEATMAP,
             "when": "more than two variables are being compared at once"},
            {"visual_type": VisualType.BOX,
             "when": "one variable is better treated as categorical"},
        ],
    }


def _binned_correlation(run_id, version_id, x_name, y_name, result,
                        sample_size, book=_NO_LABELS) -> dict[str, Any]:
    """The same relationship, at a sample size where marks would overplot.

    Not a downgrade of the scatter. At this many rows a scatter answers "is
    there ink here" rather than "how much data is here", and the two questions
    have visibly different answers in the middle of a dense cloud.
    """
    bins = 30
    spec = ResearchVisualSpec(
        visual_type=VisualType.HEXBIN,
        analysis_run_id=run_id, dataset_version_id=version_id,
        x=book.encoding(x_name),
        y=book.encoding(y_name),
        bin_count=bins,
        annotations=[Annotation(kind="regression_line",
                                text="least-squares fit, shown for orientation only")],
        title=f"{book.label(y_name)} against {book.label(x_name)}",
        caption=(f"Association between {book.described(x_name)} and "
                 f"{book.described(y_name)} across "
                 f"{sample_size:,} observations, binned into {bins} hexagonal "
                 f"cells per axis; shade shows how many observations fall in "
                 f"each cell, on a logarithmic scale — binned counts are "
                 f"heavy-tailed, and a linear ramp would collapse everything "
                 f"outside the densest cells into one shade. "
                 f"{_significance_note(result)}. "
                 f"Association does not establish causation."),
        interaction=["hover", "brush", "underlying_table"],
    )
    return {
        "visual_type": VisualType.HEXBIN,
        "reason": (f"{sample_size:,} observations would overplot as a scatter — "
                   f"the dense region fills in and a reader cannot tell where "
                   f"most of the data lies. Binning shades each cell by how many "
                   f"observations it holds, so density stays visible."),
        "spec": spec,
        "interpretation": result.get("interpretation", ""),
        "alternatives": [
            {"visual_type": VisualType.SCATTER,
             "when": "the individual observations matter more than their density, "
                     "such as when hunting outliers"},
            {"visual_type": VisualType.BOX,
             "when": "one variable is better treated as categorical"},
        ],
    }


def _regression(run_id, version_id, variables, result, audience,
                book=_NO_LABELS) -> dict[str, Any]:
    predictors = list(variables.get("predictors") or [])
    outcome = variables["outcome"]
    multiple = len(predictors) > 1
    if multiple:
        # A coefficient plot is the honest view of a multivariable model: it
        # shows every adjusted estimate with its interval side by side.
        spec = ResearchVisualSpec(
            visual_type=VisualType.FOREST,
            analysis_run_id=run_id, dataset_version_id=version_id,
            x=Encoding(field="estimate", label="coefficient (95% CI)", include_zero=True),
            y=Encoding(field="predictor", label="predictor"),
            # The y axis of a forest plot is a list of column names. Without
            # these, that axis is the one place a reader still meets the raw
            # schema — the encodings above describe the estimate, not the rows.
            category_labels=book.category_labels(predictors),
            uncertainty=UncertaintyDisplay.CONFIDENCE_INTERVAL,
            annotations=[Annotation(kind="reference_line", value=0.0,
                                    orientation="vertical", text="no effect")],
            title=f"Adjusted associations with {book.label(outcome)}",
            caption=(f"Coefficients from a multiple regression of "
                     f"{book.described(outcome)} on {book.joined(predictors)}. "
                     f"{_significance_note(result)}. "
                     "Intervals crossing zero are compatible with no effect."),
        )
        reason = ("With several predictors, a coefficient plot shows each adjusted "
                  "estimate and its interval together, which a scatter plot cannot.")
        alternatives = [{"visual_type": VisualType.SCATTER,
                         "when": "you want to show one predictor's raw relationship"}]
    else:
        spec = ResearchVisualSpec(
            visual_type=VisualType.SCATTER,
            analysis_run_id=run_id, dataset_version_id=version_id,
            x=book.encoding(predictors[0]),
            y=book.encoding(outcome),
            uncertainty=UncertaintyDisplay.BAND,
            annotations=[Annotation(kind="regression_line", text="fitted line with interval")],
            title=f"{book.label(outcome)} against {book.label(predictors[0])}",
            caption=(f"Simple linear regression of {book.described(outcome)} on "
                     f"{book.described(predictors[0])}. {_significance_note(result)}. "
                     "Association does not establish causation."),
        )
        reason = ("A single predictor is best shown as a scatter plot with the fitted "
                  "line, so the reader sees the data behind the coefficient.")
        alternatives = [{"visual_type": VisualType.FOREST,
                         "when": "predictors are added and the model becomes multivariable"}]

    return {"visual_type": spec.visual_type, "reason": reason, "spec": spec,
            "interpretation": result.get("interpretation", ""), "alternatives": alternatives}


def _group_comparison(run_id, version_id, variables, result, audience,
                      book=_NO_LABELS) -> dict[str, Any]:
    value, group = variables["value"], variables["group"]
    groups = (result.get("extra") or {}).get("groups") or {}
    many = len(groups) > 2

    # A box plot shows the distributions being compared. A bar of means hides
    # spread and overlap, which is the single most common way a group difference
    # is overstated — so it is the alternative, not the default.
    spec = ResearchVisualSpec(
        visual_type=VisualType.BOX,
        analysis_run_id=run_id, dataset_version_id=version_id,
        x=book.encoding(group),
        y=book.encoding(value),
        group=book.encoding(group),
        uncertainty=UncertaintyDisplay.NONE,
        title=f"{book.label(value)} by {book.label(group)}",
        caption=(f"Distribution of {book.described(value)} across "
                 f"{book.described(group)}. {_significance_note(result)}. "
                 "Boxes show the median and interquartile range."),
    )
    return {
        "visual_type": VisualType.BOX,
        "reason": ("A box plot shows the spread and overlap of each group. A bar of "
                   "means would hide exactly the information needed to judge whether "
                   "the groups really differ."),
        "spec": spec,
        "interpretation": result.get("interpretation", ""),
        "alternatives": [
            {"visual_type": VisualType.BAR,
             "when": "the audience needs group means and the spread is reported elsewhere"},
            {"visual_type": VisualType.HISTOGRAM,
             "when": "the shape of a single distribution matters more than the comparison"},
        ] + ([{"visual_type": VisualType.FOREST,
               "when": "pairwise differences with intervals are the point"}] if many else []),
    }


def _contingency(run_id, version_id, variables, result, audience,
                 book=_NO_LABELS) -> dict[str, Any]:
    x_name, y_name = variables["x"], variables["y"]
    spec = ResearchVisualSpec(
        visual_type=VisualType.HEATMAP,
        analysis_run_id=run_id, dataset_version_id=version_id,
        x=book.encoding(x_name),
        y=book.encoding(y_name),
        title=f"{book.label(x_name)} by {book.label(y_name)}",
        caption=(f"Contingency table of {book.described(x_name)} against "
                 f"{book.described(y_name)}. {_significance_note(result)}."),
    )
    return {
        "visual_type": VisualType.HEATMAP,
        "reason": ("A heatmap of the contingency table shows where the association "
                   "actually sits, which a single chi-square statistic cannot."),
        "spec": spec,
        "interpretation": result.get("interpretation", ""),
        "alternatives": [{"visual_type": VisualType.BAR,
                          "when": "one variable has only two levels"}],
    }


def _descriptive(run_id, version_id, variables, result, audience,
                 book=_NO_LABELS) -> dict[str, Any]:
    columns = list(variables.get("columns") or [])
    if not columns:
        raise RecommendationError("descriptive analysis named no columns to plot")
    spec = ResearchVisualSpec(
        visual_type=VisualType.HISTOGRAM,
        analysis_run_id=run_id, dataset_version_id=version_id,
        x=book.encoding(columns[0]),
        y=Encoding(field="count", label="count", include_zero=True),
        title=f"Distribution of {book.label(columns[0])}",
        caption=(f"Distribution of {book.described(columns[0])}. "
                 f"{_significance_note(result)}."),
    )
    return {
        "visual_type": VisualType.HISTOGRAM,
        "reason": ("A histogram shows the shape of the distribution — skew, spread and "
                   "gaps — before any test is applied to it."),
        "spec": spec,
        "interpretation": result.get("interpretation", ""),
        "alternatives": [{"visual_type": VisualType.BOX,
                          "when": "several distributions are being compared"}],
    }
